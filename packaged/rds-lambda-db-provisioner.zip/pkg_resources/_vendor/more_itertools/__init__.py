"""More routines for operating on iterables, beyond itertools"""

from .more import *  # noqa
from .recipes import *  # noqa

__version__ = '9.0.0'
